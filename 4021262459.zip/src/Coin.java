public class Coin {

    String coinColor;
    Coin(String coinColor) {
        this.coinColor = coinColor;
    }

    public String toString() {
        return coinColor + "";
    }
}
